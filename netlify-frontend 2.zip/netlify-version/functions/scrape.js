// Netlify Function version - experimental
// Uses @sparticuz/chromium + puppeteer-core which fits Netlify limits
// For 30 pages, it might hit 26 sec timeout on free plan. Recommended: Use Render for backend.

import chromium from '@sparticuz/chromium';
import puppeteer from 'puppeteer-core';

export async function handler(event) {
  if (event.httpMethod !== 'POST') return { statusCode: 405, body: 'POST only' };
  
  try {
    const { url, pages = 30 } = JSON.parse(event.body);
    if (!url || !url.includes('facebook.com/ads/library')) {
      return { statusCode: 400, body: JSON.stringify({ error: 'Valid Facebook Ads URL required' }) };
    }

    const browser = await puppeteer.launch({
      args: chromium.args,
      defaultViewport: chromium.defaultViewport,
      executablePath: await chromium.executablePath(),
      headless: chromium.headless,
    });

    const page = await browser.newPage();
    await page.goto(url, { waitUntil: 'domcontentloaded', timeout: 90000 });
    await new Promise(r => setTimeout(r, 7000));

    const targetPages = Math.min(parseInt(pages), 50); // limit on Netlify due to timeout
    
    for (let i = 0; i < targetPages; i++) {
      await page.evaluate(() => window.scrollTo(0, document.body.scrollHeight));
      await new Promise(r => setTimeout(r, 2000));
      await page.mouse.wheel({ deltaY: 3000 });
    }

    const screenshotBase64 = await page.screenshot({ encoding: 'base64', fullPage: true });
    const html = await page.content();
    
    await browser.close();

    return {
      statusCode: 200,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        status: 'completed',
        job_id: 'netlify-' + Date.now(),
        url,
        pages: targetPages,
        screenshot_size: screenshotBase64.length,
        html_size: html.length,
        note: 'Full file too large for Netlify function response. Use Render backend for file downloads. Screenshot truncated.',
        screenshot_preview: screenshotBase64.slice(0, 100) + '...',
      })
    };

  } catch (err) {
    console.error(err);
    return { statusCode: 500, body: JSON.stringify({ error: err.message, stack: err.stack }) };
  }
}
