# Deploy to Netlify + WordPress Guide

## Can you deploy to Netlify?

**Short answer: Frontend YES, Backend NO (directly).**

- Netlify is for static sites + short serverless functions (max 26 sec, 50MB).
- This scraper needs Playwright Chromium (~130MB) and runs 2-3 minutes for 30 pages → Too big/long for Netlify free.
- I made 2 options:

### Option A: Split Deploy (Recommended, works 100%)

1. **Backend:** Deploy `fb-ads-library-tool` (Flask app) to **Render.com** (free, supports Docker + Chromium) - 1 click from GitHub
2. **Frontend:** Deploy `netlify-version` folder to Netlify
   - Drag & drop `netlify-version` folder to https://app.netlify.com/drop
   - OR connect GitHub repo and set publish dir to `netlify-version`
   - In the UI, set backend URL to your Render URL

Your Netlify site will then call Render backend via API - user sees everything on your Netlify domain.

### Option B: Full Netlify Function (Experimental)

I included `functions/scrape.js` using @sparticuz/chromium which is Netlify-optimized.
- Works for 10-20 pages, may timeout at 30.
- For production, increase to 60 sec timeout (Netlify Pro) or use background functions.

Deploy:
```
cd netlify-version
npm install
netlify deploy --prod
```

## Can you deploy to WordPress?

**WordPress is PHP, cannot run Python Playwright directly.**

But I built you a **WordPress Plugin** that solves it:

Path: `fb-ads-library-tool-wordpress/fb-ads-scraper-tool/`

### How to install:

1. Zip the folder `fb-ads-scraper-tool`
2. WordPress → Plugins → Add New → Upload Plugin → Choose zip → Activate
3. Go to `FB Ads Scraper → Settings` → Paste your Render backend URL
4. Use:
   - Admin page: `FB Ads Scraper` in WP sidebar
   - Frontend via shortcode: `[fb_ads_scraper backend_url="https://your-backend.onrender.com"]`
   - Any post/page: add shortcode

### Architecture:

WordPress (PHP) = UI only
↓ API calls to
Render (Flask + Chromium) = actual scraper that does Facebook scrolling

This way you get WordPress domain + admin panel, but scraping power of Render.

Iframe alternative: You can also embed your Render app in WordPress with `<iframe src="https://your-backend.onrender.com" width="100%" height="800"></iframe>`

## What to host where - Summary:

| Platform | Can host scraper? | Best for |
|----------|------------------|----------|
| **Render.com** | ✅ YES | Backend - recommended free |
| **Netlify** | ⚠️ Frontend only | Static UI, drag drop |
| **Vercel** | ⚠️ Complicated | Needs custom chromium |
| **WordPress** | ❌ PHP only | UI via plugin + shortcode, backend separate |
| **GitHub Actions** | ✅ YES | No host, run on demand, download artifact |

Need help connecting WordPress + Render? Give me your domains.
